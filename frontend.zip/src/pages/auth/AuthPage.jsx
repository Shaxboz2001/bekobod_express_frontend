import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  CircularProgress,
  Alert,
  Avatar,
  TextField,
  InputAdornment,
  Stepper,
  Step,
  StepLabel,
} from "@mui/material";
import {
  LocalTaxi,
  DirectionsCar,
  Person,
  Phone,
  ArrowForward,
  CheckCircle,
} from "@mui/icons-material";
import { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { useMutation } from "react-query";
import { useNavigate } from "react-router-dom";
import { authApi } from "../../api/services";
import { setCredentials } from "../../features/auth/authSlice";
import { useTelegram } from "../../hooks/useTelegram";

const ADMIN_URL = process.env.REACT_APP_ADMIN_URL || "http://localhost:3001";

const S = {
  LOADING: "loading",
  ROLE_SELECT: "role_select",
  PHONE: "phone",
  SUCCESS: "success",
  PENDING: "pending",
  ERROR: "error",
};

export default function AuthPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { tgUser, isInsideTelegram, haptic, ready } = useTelegram();

  const [screen, setScreen] = useState(S.LOADING);
  const [role, setRole] = useState("");
  const [phone, setPhone] = useState("");
  const [phoneErr, setPhoneErr] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  // ── Saqlash va yo'naltirish ──────────────────────────────────────────────
  const saveAndRedirect = (data) => {
    dispatch(
      setCredentials({
        user: data.user,
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
      }),
    );
    const u = data.user;
    if (u.role === "admin") {
      const stored = JSON.parse(localStorage.getItem("bekobod_auth") || "{}");
      window.location.href = `${ADMIN_URL}?token=${stored.accessToken}&refresh=${stored.refreshToken}`;
    } else if (u.role === "driver") {
      navigate("/active-trips", { replace: true });
    } else {
      navigate("/new-trip", { replace: true });
    }
  };

  // ── Telegram login mutation ──────────────────────────────────────────────
  const loginMut = useMutation(
    (payload) => authApi.telegram(payload).then((r) => r.data),
    {
      onSuccess: saveAndRedirect,
      onError: (err) => {
        const d = err.response?.data?.detail;
        if (d === "NEED_REGISTRATION") {
          setScreen(S.ROLE_SELECT);
          return;
        }
        if (d === "DRIVER_NOT_VERIFIED") {
          setScreen(S.PENDING);
          return;
        }
        setErrorMsg(d || "Xato yuz berdi");
        setScreen(S.ERROR);
      },
    },
  );

  // ── Ro'yxatdan o'tish mutation ───────────────────────────────────────────
  const registerMut = useMutation(
    (payload) => authApi.telegram(payload).then((r) => r.data),
    {
      onSuccess: (data) => {
        haptic?.("medium");
        if (data.user.role === "driver") {
          setScreen(S.SUCCESS);
        } else {
          saveAndRedirect(data);
        }
      },
      onError: (err) => {
        const d = err.response?.data?.detail;
        if (d === "DRIVER_NOT_VERIFIED") {
          setScreen(S.SUCCESS);
          return;
        }
        setPhoneErr(d || "Xato yuz berdi");
      },
    },
  );

  // ── Avtomatik kirish (ready bo'lgandan keyin) ────────────────────────────
  useEffect(() => {
    if (!ready) return;

    if (isInsideTelegram && tgUser) {
      // Telegram ichida + user bor → avtomatik kirish
      loginMut.mutate({
        telegram_id: tgUser.id,
        full_name: [tgUser.first_name, tgUser.last_name]
          .filter(Boolean)
          .join(" "),
        username: tgUser.username || null,
      });
    } else if (isInsideTelegram && !tgUser) {
      // Telegram ichida lekin user hali kelmagan → 1 soniya kutib qayta urinish
      const timer = setTimeout(() => {
        const user = window.Telegram?.WebApp?.initDataUnsafe?.user;
        if (user) {
          loginMut.mutate({
            telegram_id: user.id,
            full_name: [user.first_name, user.last_name]
              .filter(Boolean)
              .join(" "),
            username: user.username || null,
          });
        } else {
          setScreen(S.ROLE_SELECT);
        }
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      // Browser (Telegram ichida emas) → rol tanlash
      setScreen(S.ROLE_SELECT);
    }
  }, [ready, isInsideTelegram]); // eslint-disable-line

  // ── Rol tanlash ──────────────────────────────────────────────────────────
  const onRoleSelect = (r) => {
    haptic?.("light");
    setRole(r);
    setPhone("");
    setPhoneErr("");
    setScreen(S.PHONE);
  };

  // ── Telefon yuborish ─────────────────────────────────────────────────────
  const onSubmitPhone = () => {
    setPhoneErr("");
    const cleaned = phone.replace(/\D/g, "");
    if (cleaned.length < 9) {
      setPhoneErr("To'g'ri telefon raqam kiriting");
      return;
    }
    haptic?.("light");

    const fullPhone = cleaned.startsWith("998") ? cleaned : `998${cleaned}`;

    if (isInsideTelegram && tgUser) {
      registerMut.mutate({
        telegram_id: tgUser.id,
        full_name: [tgUser.first_name, tgUser.last_name]
          .filter(Boolean)
          .join(" "),
        username: tgUser.username || null,
        phone: fullPhone,
        role,
      });
    } else {
      // Browser test — demo login
      const demos = { driver: "998901111111", passenger: "998903333333" };
      authApi
        .login({
          phone: demos[role],
          password: role === "driver" ? "driver123" : "user123",
        })
        .then((r) => saveAndRedirect(r.data))
        .catch(() => setPhoneErr("Demo login xatosi"));
    }
  };

  // ── Qayta urinish ────────────────────────────────────────────────────────
  const retryLogin = () => {
    setScreen(S.LOADING);
    const user = window.Telegram?.WebApp?.initDataUnsafe?.user || tgUser;
    if (user) {
      loginMut.mutate({
        telegram_id: user.id,
        full_name: [user.first_name, user.last_name].filter(Boolean).join(" "),
        username: user.username || null,
      });
    } else {
      setScreen(S.ROLE_SELECT);
    }
  };

  // ════════════════════════════════════════════════════════════════════════════
  // LOADING ekrani
  if (screen === S.LOADING)
    return (
      <CenterBox>
        <LogoBox />
        <Typography variant="h6" fontWeight={700} mt={2}>
          Bekobod Express
        </Typography>
        <CircularProgress sx={{ mt: 3, color: "#1a1a2e" }} size={32} />
        <Typography variant="body2" color="text.secondary" mt={1.5}>
          Kirilmoqda...
        </Typography>
      </CenterBox>
    );

  // ROLE SELECT ekrani
  if (screen === S.ROLE_SELECT)
    return (
      <CenterBox>
        <LogoBox />
        <Typography variant="h5" fontWeight={700} mt={2}>
          Bekobod Express
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Bekobod ↔ Toshkent
        </Typography>

        {tgUser && (
          <Card sx={{ width: "100%", maxWidth: 340, mb: 2 }}>
            <CardContent
              sx={{ display: "flex", alignItems: "center", gap: 1.5, py: 1.5 }}
            >
              <Avatar sx={{ bgcolor: "#1a1a2e", width: 40, height: 40 }}>
                {tgUser.first_name?.[0]}
              </Avatar>
              <Box>
                <Typography variant="body2" fontWeight={600}>
                  {[tgUser.first_name, tgUser.last_name]
                    .filter(Boolean)
                    .join(" ")}
                </Typography>
                {tgUser.username && (
                  <Typography variant="caption" color="text.secondary">
                    @{tgUser.username}
                  </Typography>
                )}
              </Box>
            </CardContent>
          </Card>
        )}

        <Card sx={{ width: "100%", maxWidth: 340 }}>
          <CardContent sx={{ p: 2.5 }}>
            <Typography
              variant="subtitle2"
              fontWeight={700}
              mb={2}
              textAlign="center"
            >
              Rolni tanlang
            </Typography>

            <RoleCard
              icon={<Person sx={{ fontSize: 26, color: "#1a1a2e" }} />}
              bg="#e8f4fd"
              title="Yo'lovchi"
              desc="Taksi chaqiraman"
              border="#1a1a2e"
              hoverBg="#f0f4ff"
              onClick={() => onRoleSelect("passenger")}
              mb={1.5}
            />
            <RoleCard
              icon={<DirectionsCar sx={{ fontSize: 26, color: "#f5a623" }} />}
              bg="#fff8e1"
              title="Haydovchi"
              desc="E'lonlarni qabul qilaman"
              border="#f5a623"
              hoverBg="#fffbf0"
              onClick={() => onRoleSelect("driver")}
              mb={0}
            />
          </CardContent>
        </Card>
      </CenterBox>
    );

  // PHONE ekrani
  if (screen === S.PHONE)
    return (
      <CenterBox>
        <LogoBox small />
        <Card sx={{ width: "100%", maxWidth: 340, mt: 2 }}>
          <CardContent sx={{ p: 2.5 }}>
            <Stepper activeStep={1} sx={{ mb: 3 }}>
              <Step completed>
                <StepLabel>Rol</StepLabel>
              </Step>
              <Step active>
                <StepLabel>Telefon</StepLabel>
              </Step>
              <Step>
                <StepLabel>Kirish</StepLabel>
              </Step>
            </Stepper>

            <Typography variant="subtitle1" fontWeight={700} mb={0.5}>
              {role === "driver" ? "🚗 Haydovchi" : "👤 Yo'lovchi"} sifatida
            </Typography>
            <Typography variant="body2" color="text.secondary" mb={2.5}>
              Telefon raqamingizni kiriting
            </Typography>

            <TextField
              label="Telefon raqam"
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value);
                setPhoneErr("");
              }}
              onKeyDown={(e) => e.key === "Enter" && onSubmitPhone()}
              fullWidth
              placeholder="901234567"
              error={!!phoneErr}
              helperText={phoneErr || " "}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Phone fontSize="small" color="action" />
                    <Typography
                      variant="body2"
                      sx={{ ml: 0.5, mr: 0.5, color: "text.secondary" }}
                    >
                      +998
                    </Typography>
                  </InputAdornment>
                ),
              }}
              autoFocus
              sx={{ mb: 1 }}
            />

            {role === "driver" && (
              <Box
                sx={{
                  p: 1.5,
                  bgcolor: "#fff8e1",
                  borderRadius: 2,
                  mb: 2,
                  border: "1px solid #ffe082",
                }}
              >
                <Typography variant="caption" color="text.secondary">
                  ⚠️ Haydovchi sifatida ro'yxatdan o'tgach admin tasdiqlashi
                  kerak
                </Typography>
              </Box>
            )}

            <Button
              fullWidth
              variant="contained"
              size="large"
              onClick={onSubmitPhone}
              disabled={registerMut.isLoading || !phone}
              endIcon={
                registerMut.isLoading ? (
                  <CircularProgress size={18} color="inherit" />
                ) : (
                  <ArrowForward />
                )
              }
              sx={{ bgcolor: "#1a1a2e", borderRadius: 3, py: 1.5, mb: 1.5 }}
            >
              {registerMut.isLoading ? "Kirilmoqda..." : "Davom etish"}
            </Button>

            <Button
              fullWidth
              variant="text"
              size="small"
              onClick={() => setScreen(S.ROLE_SELECT)}
              sx={{ color: "text.secondary" }}
            >
              ← Orqaga
            </Button>
          </CardContent>
        </Card>
      </CenterBox>
    );

  // SUCCESS / PENDING ekrani
  if (screen === S.SUCCESS || screen === S.PENDING)
    return (
      <CenterBox>
        <Box
          sx={{
            width: 80,
            height: 80,
            bgcolor: screen === S.SUCCESS ? "#f0fff4" : "#fff8e1",
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            mb: 2,
          }}
        >
          {screen === S.SUCCESS ? (
            <CheckCircle sx={{ fontSize: 44, color: "#27ae60" }} />
          ) : (
            <DirectionsCar sx={{ fontSize: 44, color: "#f5a623" }} />
          )}
        </Box>

        <Typography variant="h6" fontWeight={700} mb={1} textAlign="center">
          {screen === S.SUCCESS
            ? "Muvaffaqiyatli ro'yxatdan o'tdingiz! 🎉"
            : "Kutilmoqda ⏳"}
        </Typography>
        <Typography
          variant="body2"
          color="text.secondary"
          mb={3}
          textAlign="center"
          sx={{ maxWidth: 280 }}
        >
          Admin profilingizni tekshirib, tez orada faollashtiradi. Telegram
          orqali xabar keladi.
        </Typography>

        <Card sx={{ width: "100%", maxWidth: 300, bgcolor: "#f4f6f9" }}>
          <CardContent sx={{ py: 2 }}>
            {[
              "📋 Admin profilni ko'rib chiqadi",
              "📩 Telegram xabar keladi",
              "✅ Kirish faollashadi",
            ].map((t, i) => (
              <Typography
                key={i}
                variant="body2"
                color="text.secondary"
                sx={{ mb: 0.75 }}
              >
                {t}
              </Typography>
            ))}
          </CardContent>
        </Card>

        <Button
          variant="outlined"
          sx={{
            mt: 3,
            borderRadius: 3,
            borderColor: "#1a1a2e",
            color: "#1a1a2e",
          }}
          onClick={retryLogin}
        >
          🔄 Qayta tekshirish
        </Button>
      </CenterBox>
    );

  // ERROR ekrani
  return (
    <CenterBox>
      <Typography sx={{ fontSize: 56, mb: 2 }}>😕</Typography>
      <Typography variant="h6" fontWeight={700} mb={1}>
        Xato yuz berdi
      </Typography>
      <Alert severity="error" sx={{ mb: 3, maxWidth: 320 }}>
        {errorMsg}
      </Alert>
      <Button
        variant="contained"
        sx={{ bgcolor: "#1a1a2e", borderRadius: 3 }}
        onClick={() => {
          setScreen(S.LOADING);
          setErrorMsg("");
          retryLogin();
        }}
      >
        Qayta urinish
      </Button>
    </CenterBox>
  );
}

// ─── Yordamchi komponentlar ──────────────────────────────────────────────────
function CenterBox({ children }) {
  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        p: 2.5,
        bgcolor: "#f4f6f9",
      }}
    >
      {children}
    </Box>
  );
}

function LogoBox({ small }) {
  const size = small ? 56 : 72;
  return (
    <Box
      sx={{
        width: size,
        height: size,
        bgcolor: "#1a1a2e",
        borderRadius: 3,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <LocalTaxi sx={{ color: "#f5a623", fontSize: small ? 32 : 40 }} />
    </Box>
  );
}

function RoleCard({ icon, bg, title, desc, border, hoverBg, onClick, mb }) {
  return (
    <Box
      onClick={onClick}
      sx={{
        p: 2,
        borderRadius: 3,
        border: "2px solid #e8e8e8",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: 2,
        mb,
        transition: "all 0.15s",
        "&:hover": {
          borderColor: border,
          bgcolor: hoverBg,
          transform: "translateY(-2px)",
          boxShadow: "0 4px 16px rgba(0,0,0,0.10)",
        },
        "&:active": { transform: "scale(0.98)" },
      }}
    >
      <Box
        sx={{
          width: 48,
          height: 48,
          bgcolor: bg,
          borderRadius: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        {icon}
      </Box>
      <Box>
        <Typography variant="body1" fontWeight={700}>
          {title}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {desc}
        </Typography>
      </Box>
      <ArrowForward sx={{ ml: "auto", color: "text.disabled", fontSize: 18 }} />
    </Box>
  );
}
