import {
  Box, Typography, CircularProgress, Select, MenuItem,
  FormControl, Button, Chip, Alert,
} from '@mui/material';
import { Refresh } from '@mui/icons-material';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { useSnackbar } from 'notistack';
import { tripsApi } from '../../api/services';
import TripCard from '../../components/common/TripCard';
import { useState } from 'react';

export default function ActiveTripsPage() {
  const qc = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const [direction, setDirection] = useState('');
  const [category, setCategory] = useState('');
  const [acceptingId, setAcceptingId] = useState(null);

  const { data, isLoading, refetch, isError } = useQuery(
    ['active-trips', direction, category],
    () => tripsApi.active({
      page: 1, size: 30,
      ...(direction && { direction }),
      ...(category && { category }),
    }).then(r => r.data),
    { refetchInterval: 20_000 } // har 20 soniyada yangilanadi
  );

  const acceptMutation = useMutation(
    (id) => tripsApi.accept(id).then(r => r.data),
    {
      onMutate: (id) => setAcceptingId(id),
      onSuccess: (data) => {
        qc.invalidateQueries('active-trips');
        qc.invalidateQueries('my-trips');
        enqueueSnackbar(`✅ E'lon #${data.id} qabul qilindi! Yo'lovchiga xabar yuborildi.`, { variant: 'success' });
        setAcceptingId(null);
      },
      onError: (err) => {
        enqueueSnackbar(err.response?.data?.detail || "Xato yuz berdi", { variant: 'error' });
        setAcceptingId(null);
      },
    }
  );

  const trips = data?.items || [];
  const total = data?.total || 0;

  return (
    <Box>
      {/* Header */}
      <Box sx={{
        px: 2, pt: 2, pb: 1.5,
        background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
        color: '#fff',
      }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Box>
            <Typography variant="h6" fontWeight={700} color="#fff">
              🚕 Faol e'lonlar
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.7)' }}>
              {total} ta e'lon kutilmoqda
            </Typography>
          </Box>
          <Button
            size="small"
            startIcon={<Refresh />}
            onClick={() => refetch()}
            sx={{ color: '#fff', borderColor: 'rgba(255,255,255,0.3)', border: '1px solid', borderRadius: 2, px: 1.5 }}
          >
            Yangilash
          </Button>
        </Box>

        {/* Filters */}
        <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
          <FormControl size="small" sx={{ flex: 1 }}>
            <Select
              value={direction}
              onChange={e => setDirection(e.target.value)}
              displayEmpty
              sx={{ bgcolor: 'rgba(255,255,255,0.12)', color: '#fff', borderRadius: 2,
                '& .MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.2)' },
                '& .MuiSvgIcon-root': { color: '#fff' },
              }}
            >
              <MenuItem value="">Barcha yo'nalish</MenuItem>
              <MenuItem value="bekobod_to_tashkent">🚀 B→T</MenuItem>
              <MenuItem value="tashkent_to_bekobod">🏠 T→B</MenuItem>
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ flex: 1 }}>
            <Select
              value={category}
              onChange={e => setCategory(e.target.value)}
              displayEmpty
              sx={{ bgcolor: 'rgba(255,255,255,0.12)', color: '#fff', borderRadius: 2,
                '& .MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.2)' },
                '& .MuiSvgIcon-root': { color: '#fff' },
              }}
            >
              <MenuItem value="">Barcha tur</MenuItem>
              <MenuItem value="passenger">👤 Yo'lovchi</MenuItem>
              <MenuItem value="passenger_small_cargo">🎒 Yo'lovchi+yuk</MenuItem>
              <MenuItem value="cargo">📦 Yuk</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Box>

      {/* Content */}
      <Box sx={{ p: 2 }}>
        {isError && (
          <Alert severity="error" sx={{ mb: 2 }}>
            Ma'lumot yuklanmadi. Qayta urinib ko'ring.
          </Alert>
        )}

        {isLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
            <CircularProgress sx={{ color: '#1a1a2e' }} />
          </Box>
        ) : trips.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Typography sx={{ fontSize: 56, mb: 2 }}>📭</Typography>
            <Typography variant="h6" fontWeight={600} color="text.secondary">
              Hozircha e'lonlar yo'q
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              Yangi e'lonlar paydo bo'lganda bu yerda ko'rinadi
            </Typography>
            <Button
              variant="outlined"
              startIcon={<Refresh />}
              onClick={() => refetch()}
              sx={{ mt: 2, borderRadius: 2, borderColor: '#1a1a2e', color: '#1a1a2e' }}
            >
              Yangilash
            </Button>
          </Box>
        ) : (
          <>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
              <Typography variant="body2" color="text.secondary" fontWeight={500}>
                {total} ta e'lon
              </Typography>
              <Chip label="Avtomatik yangilanadi" size="small" color="success" variant="outlined" />
            </Box>
            {trips.map(trip => (
              <TripCard
                key={trip.id}
                trip={trip}
                showAccept
                onAccept={(id) => acceptMutation.mutate(id)}
                loading={acceptingId === trip.id}
              />
            ))}
          </>
        )}
      </Box>
    </Box>
  );
}
