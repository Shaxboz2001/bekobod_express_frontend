import {
  Box, Card, CardContent, Typography, Button, Chip, Divider,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField,
  CircularProgress, Alert,
} from '@mui/material';
import {
  LocationOn, FlagOutlined, ArrowBack, EventSeat,
  AccessTime, Person, DirectionsCar, Phone,
} from '@mui/icons-material';
import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { useSnackbar } from 'notistack';
import { tripsApi } from '../../api/services';
import { useSelector } from 'react-redux';
import { selectRole } from '../../features/auth/authSlice';
import { TripStatusChip } from '../../components/common/TripStatusChip';
import {
  DIRECTION, CATEGORY, CAR_TYPE, formatPrice, formatDate,
} from '../../utils/constants';

export default function TripDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const role = useSelector(selectRole);
  const qc = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const [cancelDialog, setCancelDialog] = useState(false);
  const [cancelReason, setCancelReason] = useState('');

  const { data: trip, isLoading, isError } = useQuery(
    ['trip', id],
    () => tripsApi.get(id).then(r => r.data)
  );

  const cancelMutation = useMutation(
    () => tripsApi.updateStatus(id, {
      status: 'cancelled',
      cancellation_reason: cancelReason || "Foydalanuvchi tomonidan bekor qilindi",
    }).then(r => r.data),
    {
      onSuccess: () => {
        qc.invalidateQueries(['trip', id]);
        qc.invalidateQueries('my-trips');
        enqueueSnackbar("E'lon bekor qilindi", { variant: 'info' });
        setCancelDialog(false);
      },
    }
  );

  const statusMutation = useMutation(
    (status) => tripsApi.updateStatus(id, { status }).then(r => r.data),
    {
      onSuccess: (data) => {
        qc.invalidateQueries(['trip', id]);
        qc.invalidateQueries('my-trips');
        enqueueSnackbar(`Status yangilandi: ${data.status}`, { variant: 'success' });
      },
    }
  );

  if (isLoading) return (
    <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
      <CircularProgress sx={{ color: '#1a1a2e' }} />
    </Box>
  );

  if (isError || !trip) return (
    <Box sx={{ p: 3, textAlign: 'center' }}>
      <Typography color="text.secondary">E'lon topilmadi</Typography>
      <Button onClick={() => navigate(-1)} sx={{ mt: 2 }}>Orqaga</Button>
    </Box>
  );

  const dir = DIRECTION[trip.direction];
  const cat = CATEGORY[trip.category];
  const carType = CAR_TYPE[trip.car_type_preference];
  const canCancel = ['active', 'accepted'].includes(trip.status);
  const isDriver = role === 'driver';

  return (
    <Box sx={{ pb: 3 }}>
      {/* Header */}
      <Box sx={{
        px: 2, pt: 2, pb: 2,
        background: 'linear-gradient(135deg, #1a1a2e 0%, #2d2d4e 100%)',
      }}>
        <Button
          startIcon={<ArrowBack />}
          onClick={() => navigate(-1)}
          sx={{ color: 'rgba(255,255,255,0.7)', mb: 1, px: 0 }}
          size="small"
        >
          Orqaga
        </Button>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Box>
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.6)' }}>
              E'lon #{trip.id}
            </Typography>
            <Typography variant="h6" fontWeight={700} color="#fff" sx={{ mt: 0.25 }}>
              {dir?.emoji} {dir?.label}
            </Typography>
          </Box>
          <TripStatusChip status={trip.status} />
        </Box>
      </Box>

      <Box sx={{ p: 2 }}>
        {trip.cancellation_reason && (
          <Alert severity="error" sx={{ mb: 2 }}>
            <strong>Bekor qilish sababi:</strong> {trip.cancellation_reason}
          </Alert>
        )}

        {/* Route */}
        <Card sx={{ mb: 2 }}>
          <CardContent sx={{ p: 2 }}>
            <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase' }}>
              Marshrut
            </Typography>
            <Box sx={{ mt: 1.5, display: 'flex', flexDirection: 'column', gap: 1.25 }}>
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                <Box sx={{ width: 32, height: 32, borderRadius: '50%', bgcolor: '#1a1a2e', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Typography sx={{ color: '#fff', fontSize: '0.7rem', fontWeight: 700 }}>A</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">Qabul joyi</Typography>
                  <Typography variant="body2" fontWeight={600}>{trip.pickup_point}</Typography>
                </Box>
              </Box>
              <Box sx={{ ml: '15px', borderLeft: '2px dashed #e0e0e0', height: 24 }} />
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                <Box sx={{ width: 32, height: 32, borderRadius: '50%', bgcolor: '#e74c3c', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Typography sx={{ color: '#fff', fontSize: '0.7rem', fontWeight: 700 }}>B</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">Yetkazish joyi</Typography>
                  <Typography variant="body2" fontWeight={600}>{trip.dropoff_point}</Typography>
                </Box>
              </Box>
            </Box>
          </CardContent>
        </Card>

        {/* Details */}
        <Card sx={{ mb: 2 }}>
          <CardContent sx={{ p: 2 }}>
            <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase' }}>
              Tafsilotlar
            </Typography>
            <Box sx={{ mt: 1.5, display: 'flex', flexDirection: 'column', gap: 1.25 }}>
              {[
                { icon: <AccessTime fontSize="small" />, label: 'Vaqt', value: formatDate(trip.trip_date) },
                { icon: <EventSeat fontSize="small" />, label: 'Joylar', value: `${trip.seats} ta` },
                { icon: <span style={{ fontSize: 16 }}>{cat?.emoji}</span>, label: 'Kategoriya', value: cat?.label },
                { icon: <span style={{ fontSize: 16 }}>{carType?.emoji}</span>, label: 'Mashina turi', value: carType?.label },
              ].map((item, i) => (
                <Box key={i} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, color: 'text.secondary' }}>
                    {item.icon}
                    <Typography variant="body2" color="text.secondary">{item.label}</Typography>
                  </Box>
                  <Typography variant="body2" fontWeight={600}>{item.value}</Typography>
                </Box>
              ))}
              {trip.luggage && (
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2" color="text.secondary">🧳 Yuk</Typography>
                  <Chip label="Bor" size="small" color="warning" />
                </Box>
              )}
            </Box>
            {trip.notes && (
              <Box sx={{ mt: 1.5, p: 1.25, bgcolor: '#fffbf0', borderRadius: 2, border: '1px solid #f5a623' }}>
                <Typography variant="caption" color="text.secondary">💬 {trip.notes}</Typography>
              </Box>
            )}
          </CardContent>
        </Card>

        {/* Price */}
        <Card sx={{ mb: 2, bgcolor: '#f0fff4', border: '1px solid #c6f6d5' }}>
          <CardContent sx={{ p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="body2" color="text.secondary">Narx (joy boshiga)</Typography>
                <Typography variant="caption" color="text.secondary">{formatPrice(trip.price_per_seat)} × {trip.seats}</Typography>
              </Box>
              <Typography variant="h5" fontWeight={700} color="success.main">
                {formatPrice(trip.total_price)}
              </Typography>
            </Box>
          </CardContent>
        </Card>

        {/* Driver info */}
        {trip.driver && (
          <Card sx={{ mb: 2 }}>
            <CardContent sx={{ p: 2 }}>
              <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase' }}>
                Haydovchi
              </Typography>
              <Box sx={{ mt: 1.5, display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
                <Box sx={{ width: 44, height: 44, borderRadius: '50%', bgcolor: '#f5a623', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Person sx={{ color: '#fff' }} />
                </Box>
                <Box>
                  <Typography variant="body2" fontWeight={700}>{trip.driver.full_name}</Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <Phone sx={{ fontSize: 14, color: 'text.secondary' }} />
                    <Typography variant="caption" color="text.secondary">{trip.driver.phone}</Typography>
                  </Box>
                </Box>
              </Box>
              {trip.driver.driver_profile && (
                <Box sx={{ p: 1.25, bgcolor: '#f4f6f9', borderRadius: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" color="text.secondary">Mashina</Typography>
                    <Typography variant="caption" fontWeight={600}>
                      {trip.driver.driver_profile.car_model} ({trip.driver.driver_profile.car_color})
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" color="text.secondary">Davlat raqami</Typography>
                    <Chip label={trip.driver.driver_profile.car_number} size="small" sx={{ height: 20, fontSize: '0.7rem' }} />
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="caption" color="text.secondary">Reyting</Typography>
                    <Typography variant="caption" fontWeight={600}>⭐ {trip.driver.driver_profile.rating?.toFixed(1)}</Typography>
                  </Box>
                </Box>
              )}
            </CardContent>
          </Card>
        )}

        {/* Actions */}
        {isDriver && trip.status === 'accepted' && (
          <Button
            fullWidth variant="contained" size="large"
            onClick={() => statusMutation.mutate('in_progress')}
            sx={{ mb: 1.5, bgcolor: '#2980b9', borderRadius: 3, py: 1.5 }}
          >
            🚗 Safarni boshlash
          </Button>
        )}
        {isDriver && trip.status === 'in_progress' && (
          <Button
            fullWidth variant="contained" color="success" size="large"
            onClick={() => statusMutation.mutate('completed')}
            sx={{ mb: 1.5, borderRadius: 3, py: 1.5 }}
          >
            🏁 Safarni yakunlash
          </Button>
        )}
        {canCancel && (
          <Button
            fullWidth variant="outlined" color="error" size="large"
            onClick={() => setCancelDialog(true)}
            sx={{ borderRadius: 3, py: 1.5 }}
          >
            ❌ Bekor qilish
          </Button>
        )}
      </Box>

      {/* Cancel dialog */}
      <Dialog open={cancelDialog} onClose={() => setCancelDialog(false)} maxWidth="xs" fullWidth>
        <DialogTitle>Bekor qilish</DialogTitle>
        <DialogContent>
          <TextField
            label="Sabab (ixtiyoriy)"
            value={cancelReason}
            onChange={e => setCancelReason(e.target.value)}
            fullWidth multiline rows={3}
            placeholder="Nima uchun bekor qilyapsiz?"
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 2, pb: 2 }}>
          <Button onClick={() => setCancelDialog(false)} variant="outlined">Orqaga</Button>
          <Button onClick={() => cancelMutation.mutate()} variant="contained" color="error" disabled={cancelMutation.isLoading}>
            Bekor qilish
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
