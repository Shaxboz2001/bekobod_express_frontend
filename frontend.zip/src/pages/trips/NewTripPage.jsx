import {
  Box, Card, CardContent, Typography, TextField, Button,
  ToggleButton, ToggleButtonGroup, MenuItem, Select,
  FormControl, InputLabel, Grid, Chip, CircularProgress,
  Alert, Divider, Autocomplete,
} from '@mui/material';
import {
  LocationOn, FlagOutlined, EventSeat, Schedule,
  Luggage, ArrowForward,
} from '@mui/icons-material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { tripsApi } from '../../api/services';
import { useSnackbar } from 'notistack';
import {
  DIRECTION, CATEGORY, CAR_TYPE, formatPrice,
  BEKOBOD_POINTS, TASHKENT_POINTS,
} from '../../utils/constants';
import dayjs from 'dayjs';

const INITIAL = {
  direction: 'bekobod_to_tashkent',
  pickup_point: '',
  dropoff_point: '',
  trip_date: '',
  trip_time: '',
  seats: 1,
  category: 'passenger',
  car_type_preference: 'any',
  notes: '',
  luggage: false,
};

export default function NewTripPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const [form, setForm] = useState(INITIAL);
  const [error, setError] = useState('');

  // Narxlarni olish
  const { data: pricingList = [] } = useQuery('pricing', () => tripsApi.pricing().then(r => r.data));

  // Tanlangan narx
  const pricing = pricingList.find(
    p => p.direction === form.direction && p.category === form.category
  );
  const totalPrice = pricing ? pricing.price_per_seat * form.seats : null;

  const createTrip = useMutation(
    (data) => tripsApi.create(data).then(r => r.data),
    {
      onSuccess: () => {
        qc.invalidateQueries('my-trips');
        enqueueSnackbar("E'lon muvaffaqiyatli berildi! 🎉", { variant: 'success' });
        navigate('/my-trips');
      },
      onError: (err) => setError(err.response?.data?.detail || "Xato yuz berdi"),
    }
  );

  const set = (k) => (v) => setForm(f => ({ ...f, [k]: v }));
  const setE = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const pickupOptions = form.direction === 'bekobod_to_tashkent' ? BEKOBOD_POINTS : TASHKENT_POINTS;
  const dropoffOptions = form.direction === 'bekobod_to_tashkent' ? TASHKENT_POINTS : BEKOBOD_POINTS;

  const handleSubmit = () => {
    setError('');
    if (!form.pickup_point) { setError("Qabul joyini kiriting"); return; }
    if (!form.dropoff_point) { setError("Yetkazish joyini kiriting"); return; }
    if (!form.trip_date || !form.trip_time) { setError("Sana va vaqtni kiriting"); return; }
    if (!pricing) { setError("Bu yo'nalish uchun narx belgilanmagan"); return; }

    const trip_date = new Date(`${form.trip_date}T${form.trip_time}:00`).toISOString();
    createTrip.mutate({
      direction: form.direction,
      pickup_point: form.pickup_point,
      dropoff_point: form.dropoff_point,
      trip_date,
      seats: form.seats,
      category: form.category,
      car_type_preference: form.car_type_preference,
      notes: form.notes || null,
      luggage: form.luggage,
    });
  };

  return (
    <Box sx={{ p: 2, maxWidth: 540, mx: 'auto' }}>
      <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>
        🚕 Yangi e'lon
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>
      )}

      {/* Direction */}
      <Card sx={{ mb: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Yo'nalish
          </Typography>
          <ToggleButtonGroup
            exclusive
            value={form.direction}
            onChange={(_, v) => v && setForm(f => ({ ...f, direction: v, pickup_point: '', dropoff_point: '' }))}
            fullWidth
            sx={{ mt: 1.5 }}
          >
            {Object.entries(DIRECTION).map(([key, val]) => (
              <ToggleButton
                key={key}
                value={key}
                sx={{
                  py: 1.25,
                  fontWeight: 600,
                  fontSize: '0.8rem',
                  '&.Mui-selected': { bgcolor: '#1a1a2e', color: '#fff', '&:hover': { bgcolor: '#1a1a2e' } },
                }}
              >
                {val.emoji} {val.label}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
        </CardContent>
      </Card>

      {/* Manzillar */}
      <Card sx={{ mb: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Manzillar
          </Typography>

          <Box sx={{ mt: 1.5, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            <Autocomplete
              freeSolo
              options={pickupOptions}
              value={form.pickup_point}
              onInputChange={(_, v) => set('pickup_point')(v)}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Qabul joyi"
                  InputProps={{
                    ...params.InputProps,
                    startAdornment: <LocationOn sx={{ color: '#1a1a2e', fontSize: 18, mr: 0.5 }} />,
                  }}
                />
              )}
            />

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Divider sx={{ flex: 1 }} />
              <Box sx={{ p: 0.75, bgcolor: '#f4f6f9', borderRadius: '50%', display: 'flex' }}>
                <ArrowForward sx={{ fontSize: 16, color: 'text.secondary' }} />
              </Box>
              <Divider sx={{ flex: 1 }} />
            </Box>

            <Autocomplete
              freeSolo
              options={dropoffOptions}
              value={form.dropoff_point}
              onInputChange={(_, v) => set('dropoff_point')(v)}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Yetkazish joyi"
                  InputProps={{
                    ...params.InputProps,
                    startAdornment: <FlagOutlined sx={{ color: '#e74c3c', fontSize: 18, mr: 0.5 }} />,
                  }}
                />
              )}
            />
          </Box>
        </CardContent>
      </Card>

      {/* Vaqt */}
      <Card sx={{ mb: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Sana va vaqt
          </Typography>
          <Grid container spacing={1.5} sx={{ mt: 0.5 }}>
            <Grid item xs={7}>
              <TextField
                label="Sana"
                type="date"
                value={form.trip_date}
                onChange={setE('trip_date')}
                InputLabelProps={{ shrink: true }}
                inputProps={{ min: dayjs().format('YYYY-MM-DD') }}
                fullWidth
              />
            </Grid>
            <Grid item xs={5}>
              <TextField
                label="Vaqt"
                type="time"
                value={form.trip_time}
                onChange={setE('trip_time')}
                InputLabelProps={{ shrink: true }}
                fullWidth
              />
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Kategoriya va joylar */}
      <Card sx={{ mb: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Tur va joylar
          </Typography>

          {/* Category */}
          <Box sx={{ mt: 1.5, display: 'flex', flexDirection: 'column', gap: 1 }}>
            {Object.entries(CATEGORY).map(([key, val]) => (
              <Box
                key={key}
                onClick={() => set('category')(key)}
                sx={{
                  p: 1.5, borderRadius: 2, cursor: 'pointer', border: '2px solid',
                  borderColor: form.category === key ? '#1a1a2e' : '#e0e0e0',
                  bgcolor: form.category === key ? '#f0f0ff' : 'transparent',
                  display: 'flex', alignItems: 'center', gap: 1.5,
                  transition: 'all 0.15s',
                }}
              >
                <Typography sx={{ fontSize: 24 }}>{val.emoji}</Typography>
                <Box>
                  <Typography variant="body2" fontWeight={600}>{val.label}</Typography>
                  <Typography variant="caption" color="text.secondary">{val.desc}</Typography>
                </Box>
                {form.category === key && (
                  <Chip label="✓" size="small" sx={{ ml: 'auto', bgcolor: '#1a1a2e', color: '#fff' }} />
                )}
              </Box>
            ))}
          </Box>

          {/* Seats */}
          <Box sx={{ mt: 2 }}>
            <Typography variant="body2" fontWeight={600} mb={1}>
              <EventSeat sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'middle' }} />
              Nechta joy: {form.seats}
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              {[1, 2, 3, 4].map(n => (
                <Box
                  key={n}
                  onClick={() => set('seats')(n)}
                  sx={{
                    width: 44, height: 44, borderRadius: 2, cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    border: '2px solid', fontWeight: 700,
                    borderColor: form.seats === n ? '#1a1a2e' : '#e0e0e0',
                    bgcolor: form.seats === n ? '#1a1a2e' : 'transparent',
                    color: form.seats === n ? '#fff' : 'text.primary',
                    transition: 'all 0.15s',
                  }}
                >
                  {n}
                </Box>
              ))}
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Mashina turi */}
      <Card sx={{ mb: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Mashina turi (ixtiyoriy)
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, mt: 1.5, flexWrap: 'wrap' }}>
            {Object.entries(CAR_TYPE).map(([key, val]) => (
              <Chip
                key={key}
                label={`${val.emoji} ${val.label}`}
                onClick={() => set('car_type_preference')(key)}
                variant={form.car_type_preference === key ? 'filled' : 'outlined'}
                sx={{
                  fontWeight: 600,
                  bgcolor: form.car_type_preference === key ? '#1a1a2e' : 'transparent',
                  color: form.car_type_preference === key ? '#fff' : 'text.primary',
                  borderColor: form.car_type_preference === key ? '#1a1a2e' : '#e0e0e0',
                }}
              />
            ))}
          </Box>
        </CardContent>
      </Card>

      {/* Qo'shimcha */}
      <Card sx={{ mb: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Qo'shimcha
          </Typography>
          <TextField
            label="Izoh (ixtiyoriy)"
            value={form.notes}
            onChange={setE('notes')}
            fullWidth
            multiline
            rows={2}
            placeholder="Masalan: ertalab 8:00 ga kerak..."
            sx={{ mt: 1.5 }}
          />
          <Box
            onClick={() => set('luggage')(!form.luggage)}
            sx={{
              mt: 1.5, p: 1.5, borderRadius: 2, cursor: 'pointer',
              border: '2px solid', display: 'flex', alignItems: 'center', gap: 1,
              borderColor: form.luggage ? '#f5a623' : '#e0e0e0',
              bgcolor: form.luggage ? '#fffbf0' : 'transparent',
              transition: 'all 0.15s',
            }}
          >
            <Luggage sx={{ color: form.luggage ? '#f5a623' : 'text.secondary' }} />
            <Box>
              <Typography variant="body2" fontWeight={600}>Yuk bor</Typography>
              <Typography variant="caption" color="text.secondary">Kichik sumka yoki paket</Typography>
            </Box>
            {form.luggage && <Chip label="✓" size="small" sx={{ ml: 'auto', bgcolor: '#f5a623', color: '#fff' }} />}
          </Box>
        </CardContent>
      </Card>

      {/* Narx va yuborish */}
      <Card sx={{ mb: 3, bgcolor: pricing ? '#f0fff4' : '#f4f6f9', border: `2px solid ${pricing ? '#27ae60' : '#e0e0e0'}` }}>
        <CardContent sx={{ p: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box>
              <Typography variant="body2" color="text.secondary">Umumiy narx</Typography>
              {pricing ? (
                <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                  {formatPrice(pricing.price_per_seat)} × {form.seats} joy
                </Typography>
              ) : (
                <Typography variant="caption" color="error">Narx topilmadi</Typography>
              )}
            </Box>
            <Typography variant="h5" fontWeight={700} color={pricing ? 'success.main' : 'text.disabled'}>
              {totalPrice ? formatPrice(totalPrice) : '—'}
            </Typography>
          </Box>
        </CardContent>
      </Card>

      <Button
        variant="contained"
        size="large"
        fullWidth
        disabled={createTrip.isLoading || !pricing}
        onClick={handleSubmit}
        sx={{ bgcolor: '#1a1a2e', py: 1.75, borderRadius: 3, fontSize: '1rem', fontWeight: 700, mb: 1 }}
      >
        {createTrip.isLoading
          ? <CircularProgress size={24} color="inherit" />
          : `🚕 E'lon berish — ${totalPrice ? formatPrice(totalPrice) : '...'}`
        }
      </Button>
    </Box>
  );
}
