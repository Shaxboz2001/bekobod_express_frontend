export const DIRECTION = {
  bekobod_to_tashkent: { label: 'Bekobod → Toshkent', emoji: '🚀' },
  tashkent_to_bekobod: { label: 'Toshkent → Bekobod', emoji: '🏠' },
};
export const CATEGORY = {
  passenger:             { label: "Yo'lovchi",              emoji: '👤' },
  passenger_small_cargo: { label: "Yo'lovchi + kichik yuk", emoji: '🎒' },
  cargo:                 { label: 'Yuk tashish',            emoji: '📦' },
};
export const TRIP_STATUS = {
  active:      { label: 'Faol',          color: 'warning' },
  accepted:    { label: 'Qabul',         color: 'info'    },
  in_progress: { label: "Yo'lda",        color: 'primary' },
  completed:   { label: 'Bajarildi',     color: 'success' },
  cancelled:   { label: 'Bekor',         color: 'error'   },
  expired:     { label: "Muddati o'tdi", color: 'default' },
};
export const USER_ROLE = {
  admin:     { label: 'Admin',     color: 'error'   },
  driver:    { label: 'Haydovchi', color: 'info'    },
  passenger: { label: "Yo'lovchi", color: 'default' },
};
export const CAR_TYPE = {
  any:       { label: 'Istalgan',    emoji: '🚗' },
  sedan:     { label: 'Sedan',       emoji: '🚙' },
  minivan:   { label: 'Minivan',     emoji: '🚐' },
  cargo_van: { label: 'Yuk mashina', emoji: '🚛' },
};
export const formatPrice = n =>
  n != null ? new Intl.NumberFormat('uz-UZ').format(n) + " so'm" : '—';
export const formatDate = d =>
  d ? new Date(d).toLocaleString('uz-UZ', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  }) : '—';