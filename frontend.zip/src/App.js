import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import { QueryClient, QueryClientProvider } from 'react-query';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import { SnackbarProvider } from 'notistack';
import { store } from './app/store';
import theme from './app/theme';

import AppLayout from './components/layout/AppLayout';
import AuthPage from './pages/auth/AuthPage';
import NewTripPage from './pages/trips/NewTripPage';
import MyTripsPage from './pages/trips/MyTripsPage';
import ActiveTripsPage from './pages/trips/ActiveTripsPage';
import TripDetailPage from './pages/trips/TripDetailPage';
import ProfilePage from './pages/profile/ProfilePage';

const qc = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 20_000 },
  },
});

function RequireAuth({ children }) {
  const { isAuthenticated } = store.getState().auth;
  return isAuthenticated ? children : <Navigate to="/auth" replace />;
}

function RoleRedirect() {
  const { user, isAuthenticated } = store.getState().auth;
  if (!isAuthenticated) return <Navigate to="/auth" replace />;
  return <Navigate to={user?.role === 'driver' ? '/active-trips' : '/new-trip'} replace />;
}

export default function App() {
  return (
    <Provider store={store}>
      <QueryClientProvider client={qc}>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          <SnackbarProvider
            maxSnack={3}
            anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
            autoHideDuration={3500}
          >
            <BrowserRouter>
              <Routes>
                <Route path="/auth" element={<AuthPage />} />
                <Route path="/" element={<RoleRedirect />} />

                <Route element={<RequireAuth><AppLayout /></RequireAuth>}>
                  <Route path="/new-trip"     element={<NewTripPage />} />
                  <Route path="/my-trips"     element={<MyTripsPage />} />
                  <Route path="/active-trips" element={<ActiveTripsPage />} />
                  <Route path="/trips/:id"    element={<TripDetailPage />} />
                  <Route path="/profile"      element={<ProfilePage />} />
                </Route>

                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BrowserRouter>
          </SnackbarProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </Provider>
  );
}
