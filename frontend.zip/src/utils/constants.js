export const DIRECTION = {
  bekobod_to_tashkent: { label: 'Bekobod → Toshkent', short: 'B→T', emoji: '🚀' },
  tashkent_to_bekobod: { label: 'Toshkent → Bekobod', short: 'T→B', emoji: '🏠' },
};

export const CATEGORY = {
  passenger:              { label: 'Yo\'lovchi',              emoji: '👤', desc: '1-4 joy' },
  passenger_small_cargo:  { label: 'Yo\'lovchi + kichik yuk', emoji: '🎒', desc: 'kichik sumka' },
  cargo:                  { label: 'Yuk tashish',             emoji: '📦', desc: 'katta yuk' },
};

export const CAR_TYPE = {
  any:       { label: 'Istalgan',     emoji: '🚗' },
  sedan:     { label: 'Sedan',        emoji: '🚙' },
  minivan:   { label: 'Minivan',      emoji: '🚐' },
  cargo_van: { label: 'Yuk mashina',  emoji: '🚛' },
};

export const TRIP_STATUS = {
  active:      { label: 'Kutilmoqda',     color: 'warning',  emoji: '⏳' },
  accepted:    { label: 'Qabul qilindi',  color: 'info',     emoji: '✅' },
  in_progress: { label: 'Yo\'lda',        color: 'primary',  emoji: '🚗' },
  completed:   { label: 'Yakunlandi',     color: 'success',  emoji: '🏁' },
  cancelled:   { label: 'Bekor qilindi',  color: 'error',    emoji: '❌' },
  expired:     { label: 'Muddati o\'tdi', color: 'default',  emoji: '⌛' },
};

export const formatPrice = (n) =>
  n ? new Intl.NumberFormat('uz-UZ').format(n) + ' so\'m' : '—';

export const formatDate = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleString('uz-UZ', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
};

export const formatDateOnly = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('uz-UZ', {
    day: '2-digit', month: 'long', year: 'numeric',
  });
};

export const formatTime = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' });
};

// Bekobod da qabul joylari
export const BEKOBOD_POINTS = [
  'Bekobod bozor',
  'Bekobod markaziy ko\'cha',
  'Sirdaryо ko\'prigi',
  'Bekobod temir yo\'l stansiyasi',
  'Yangi mahalla',
  'Metallurg mahallasi',
  'Eski shahar',
];

// Toshkentda yetkazish joylari
export const TASHKENT_POINTS = [
  'Toshkent — Yunusobod',
  'Toshkent — Chilonzor',
  'Toshkent — Mirzo Ulug\'bek',
  'Toshkent — Sergeli',
  'Toshkent — Shayxontohur',
  'Toshkent — Yakkasaroy',
  'Toshkent — Olmazor',
  'Toshkent — Uchtepa',
  'Toshkent — Bektemir',
  'Toshkent temir yo\'l vokzali',
  'Toshkent Janubiy avtobus bekati',
];
