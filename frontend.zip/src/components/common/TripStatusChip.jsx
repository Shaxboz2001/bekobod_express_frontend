import { Chip } from '@mui/material';
import { TRIP_STATUS } from '../../utils/constants';

export function TripStatusChip({ status, size = 'small' }) {
  const cfg = TRIP_STATUS[status] || { label: status, color: 'default', emoji: '' };
  return (
    <Chip
      label={`${cfg.emoji} ${cfg.label}`}
      color={cfg.color}
      size={size}
      sx={{ fontWeight: 600 }}
    />
  );
}
