import { Box, BottomNavigation, BottomNavigationAction, Paper } from '@mui/material';
import { AddCircleOutline, ListAlt, Person, DirectionsCar } from '@mui/icons-material';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectRole } from '../../features/auth/authSlice';

const passengerTabs = [
  { label: "E'lon",     icon: <AddCircleOutline />, path: '/new-trip' },
  { label: 'Tarixim',   icon: <ListAlt />,           path: '/my-trips' },
  { label: 'Profil',    icon: <Person />,             path: '/profile' },
];

const driverTabs = [
  { label: 'E\'lonlar',  icon: <ListAlt />,           path: '/active-trips' },
  { label: 'Mening',    icon: <DirectionsCar />,      path: '/my-trips' },
  { label: 'Profil',    icon: <Person />,             path: '/profile' },
];

export default function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const role = useSelector(selectRole);

  const tabs = role === 'driver' ? driverTabs : passengerTabs;
  const current = tabs.findIndex(t => location.pathname.startsWith(t.path));

  return (
    <Box sx={{ pb: '72px', minHeight: '100vh', bgcolor: 'background.default' }}>
      <Outlet />
      <Paper
        elevation={0}
        sx={{ position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 100 }}
      >
        <BottomNavigation
          value={current === -1 ? false : current}
          onChange={(_, i) => navigate(tabs[i].path)}
        >
          {tabs.map(t => (
            <BottomNavigationAction key={t.path} label={t.label} icon={t.icon} />
          ))}
        </BottomNavigation>
      </Paper>
    </Box>
  );
}
