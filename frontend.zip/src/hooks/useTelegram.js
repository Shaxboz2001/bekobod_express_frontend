import { useEffect, useState } from "react";

/**
 * Telegram Web App SDK wrapper
 * Telegram ichida ishlasa — tg.initDataUnsafe.user dan foydalanuvchi ma'lumotlari olinadi
 */

const tg = window.Telegram?.WebApp;

export function useTelegram() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (tg) {
      tg.ready();
      tg.expand(); // To'liq ekranga kengaytir
      setReady(true);
    } else {
      // Browser da test qilish uchun
      setReady(true);
    }
  }, []);

  const tgUser = tg?.initDataUnsafe?.user || null;

  return {
    tg,
    ready,
    // Telegram foydalanuvchisi
    tgUser,
    tgUserId: tgUser?.id || null,
    tgFullName: tgUser
      ? [tgUser.first_name, tgUser.last_name].filter(Boolean).join(" ")
      : null,
    tgUsername: tgUser?.username || null,
    // Telegram ichidami?
    isInsideTelegram: !!tg?.initDataUnsafe?.user,
    // Theme
    colorScheme: tg?.colorScheme || "light",
    themeParams: tg?.themeParams || {},
    // Main button
    showMainButton: (text, onClick) => {
      if (!tg) return;
      tg.MainButton.setText(text);
      tg.MainButton.onClick(onClick);
      tg.MainButton.show();
    },
    hideMainButton: () => tg?.MainButton?.hide(),
    // Back button
    showBackButton: (onClick) => {
      if (!tg) return;
      tg.BackButton.onClick(onClick);
      tg.BackButton.show();
    },
    hideBackButton: () => tg?.BackButton?.hide(),
    // Haptic feedback
    haptic: (type = "light") => tg?.HapticFeedback?.impactOccurred(type),
    // Close app
    close: () => tg?.close(),
  };
}
